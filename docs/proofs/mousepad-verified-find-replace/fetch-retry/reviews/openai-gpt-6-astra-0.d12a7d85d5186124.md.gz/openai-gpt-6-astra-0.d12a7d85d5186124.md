## Must fix
**Do not set `limitations: []` yet: one transcription discrepancy remains unaddressed.** T3’s zoom report still transcribes every separator as `-`, while the declaration specifies `—` (`/tmp/mousepad-fetch-retry.pvwupc_f/t3/zoom-inspection.json:18–20,29–31`; `t3/trial.json:8–10`). This is not proof the desktop text is wrong, but “no unresolved visual mismatch” needs an explicit reconciliation of that discrepancy—not just the corrected `0`/`8`.

## Risks & questions
- **The Save resolution is valid.** The visual contract does not require a visible menu interaction; it requires inspected media, matching checkpoints and no unresolved review limitations (`docs/proofs/mousepad-verified-find-replace/model-review.mjs:21–45`). Preserve “Save interaction not visually observed”; attribute saved bytes to the disk oracle and Save/readback calls to the journal. Do not describe those as Gemini’s visual observations.
- The zoom report supports resolving the suffix misread (`t3/zoom-inspection.json:14–33`). Honest Gemini inspection/Wren reconciliation attribution is compatible with the reviewer field; human approval remains separately pending (`model-review.mjs:23,98`).
- I inspected the text records, not rendered media, and did not recompute media hashes.

## Suggested improvements
Record each original limitation and its resolution, with artifact references, in the comparisons or an attached adjudication record. **After the punctuation discrepancy is reconciled**, `limitations: []` can mean “no unresolved acceptance limitations”—not “video independently proved saving.”