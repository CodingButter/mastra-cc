## Must fix

None **if `review.json` does not claim that Gemini established the Unicode code point**.

The existing validator in `model-review.mjs:31-39` does not require visual inspection to prove exact Unicode bytes. It requires nonempty comparisons and `matches: true`; exact saved content is already bound separately through `savedSha256` (`:29`) and the verification call (`:30,43`).

The unsupported part is specifically the t3 label **“U+2013”**. The evidence supports only “a visibly long dash,” while the authoritative public/disk oracle says U+2014. That is not a contradiction requiring rejection once the visual claim is narrowed.

## Risks & questions

- Any t3 comparison stating or implying that the image/OCR proved U+2014—or U+2013—is dishonest and should keep the review pending until corrected.
- `limitations: []` remains valid only if the comparison explicitly scopes visual evidence to:
  - correct fields and replacement token;
  - three-line visible result;
  - visibly long separator, without code-point attribution.
- Exact Unicode identity and post-save bytes must be attributed exclusively to the unchanged disk/public-readback oracle.
- Do not describe the initial U+2013 classification as confirmed. Preserve it as a contradictory model interpretation, superseded for visual content by the corrected scoped reading.

## Suggested improvements

Use a t3 comparison along these lines:

> Gemini confirms the search and replacement fields, replacement token, and three-line visible result. The separator appears as a long dash, but image inspection does not establish its Unicode code point; the initial U+2013 label conflicts with the authoritative U+2014 disk/readback oracle. Exact punctuation bytes and post-save content are established by those unchanged oracles, not OCR.

Comparing prefix/separator pixels before and after is optional. It can establish visual preservation of the separator shape, but it cannot establish the Unicode code point and should not be used to imply that it does.