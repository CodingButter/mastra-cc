## Must fix

None, provided the resulting `review.json` records the save-visibility issue as resolved rather than silently omitting it.

`model-review.mjs:21-45` does **not** require the video to show a File → Save menu interaction. It requires:

- nonempty reviewer and valid post-capture timestamp;
- hashes binding review to the journal, declaration, and saved bytes;
- `limitations: []`;
- all four distinct checkpoint artifacts with `matches: true`;
- the verified checkpoint tied to `trace.verification`.

The separate disk/save oracle is exactly the appropriate evidence for durability. The video’s asterisk transition and the journal’s `activateElement Save` plus fresh readback reconcile the visual observation; they do not require Gemini to claim that it saw a menu click.

## Risks & questions

- Do not copy Gemini’s `visual-inspection.json.limitations` into `review.json.limitations`. That would correctly remain pending under `model-review.mjs:31`. Instead, the review comparison fields must explicitly state that the limitation was resolved by the independent exact-byte/save/readback oracle, while preserving the honest fact that the menu interaction was not visually observed.

- `review.json` must attribute image/video inspection to Gemini and journal reconciliation to the reviewer/oracle process. It must not identify Wren as having directly viewed the media.

- The t3 initial visual misread must not be hidden. The final review should bind the zoom artifacts and explain that the initial response was superseded by the later blind zoom inspection. The final checkpoint comparisons must describe the corrected values and contain no unresolved ambiguity.

- This can be `COMPLETE` only after the review file passes the immutable hash/timestamp/checkpoint checks. The batch’s machine GREEN result alone does not establish visual acceptance.

## Suggested improvements

- Include a comparison for each trial explicitly stating: “Save menu action not visible; durability established independently by exact saved bytes, journaled Save activation, and fresh post-save readback.” This satisfies the unchanged validator without overstating visual evidence.

- Retain both the initial and zoom visual artifacts in the review provenance, with the zoom response designated as the authoritative correction for t3.