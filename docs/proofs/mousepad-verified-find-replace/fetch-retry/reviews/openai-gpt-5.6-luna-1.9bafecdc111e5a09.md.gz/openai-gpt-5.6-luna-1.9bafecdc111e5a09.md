## Must fix

None identified.

The retry boundary is now correctly narrow:

- `model-rate.mjs:25-35` constructs the outgoing request before the `try` and retries only rejection of the awaited fetch operation.
- `model-rate.mjs:36-45` handles HTTP 429 separately and does not retry body consumption or response processing failures.
- `model-rate.mjs:29` checks the combined original/request abort signal before scheduling another attempt.
- The shared attempt loop preserves the three-total-attempt cap and the existing spacing (`:20-24`), while `agent.generate` and tool execution remain outside this retry layer.

The added tests and installed-SDK probe address the material ambiguity: pre-response rejection retries; body failure, HTTP 500, foreign origin, and persistent rejection do not escape the cap.

## Risks & questions

- `model-rate.mjs:27-34` treats every rejection of `fetch(outgoing)` as retryable, including arbitrary adapter-generated errors that happen before a `Response` exists. That is consistent with the declared `retryBeforeResponse` policy, but it is broader than proven network-failure classification. No current defect is demonstrated.

- `model-rate.mjs:42` awaits 429 response-body cancellation outside the retry catch. If cancellation rejects, the request fails without retry. This is conservative and avoids replay after uncertain body cleanup, but should remain documented as intentional.

- The combined signal is checked before retry (`:29`) and passed to the outgoing `Request` (`:25`). The queue promise may still advance after a caller has already received an abort rejection, but `run` checks the same signal before network work (`:15,21,29`), so no later request should be sent.

- The installed probe establishes interception and retry behavior, not a completed Mousepad batch or acceptance result. No full-batch claim is warranted yet.

## Suggested improvements

- Add a comment or test naming the contract explicitly: any rejection before `fetch` returns a `Response` is eligible for bounded retry; any failure after a `Response` is returned is not.

- Record whether a retry was caused by a fetch rejection versus HTTP 429 in the final evidence schema. The current separate event names are useful, but the batch-level validator should reject unexpected retry event types if policy evidence is meant to be immutable.